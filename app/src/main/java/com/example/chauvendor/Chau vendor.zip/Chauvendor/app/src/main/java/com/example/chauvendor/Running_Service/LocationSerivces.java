package com.example.chauvendor.Running_Service;

import android.app.NotificationChannel;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import androidx.annotation.Nullable;

import com.google.android.gms.location.LocationServices;

public class LocationSerivces  extends Service {


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
